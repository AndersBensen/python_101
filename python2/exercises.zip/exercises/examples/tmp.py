from table import * 

kitchen_table = Table(4, "Wood", 120)
living_room_table = Table(4, "Plastic", 60)
office_table = Table(2, "Metal", 130)

kitchen_table.print_table()
living_room_table.print_table()
office_table.print_table()

