# points.txt er ikke sorteret, elementer kommer altså i tilfældig 
# rækkefølge. Matplotlib tegner en linje fra et punkt til næste,
# så hvis punkterne ikke kommer i rigtig rækkefølge så bliver 
# plottet meget mærkeligt!