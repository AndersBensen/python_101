import random
random_list = []

for i in range(20):
    random_list.append(random.randint(1,100))

print(random_list)
