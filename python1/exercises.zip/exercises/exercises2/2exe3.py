def is_equal(number):
    if (number % 2 == 0):
        return True
    else:
        return False; 

print(is_equal(10))
print(is_equal(100))
print(is_equal(11))
print(is_equal(39))