
degress_celsius = 20 
celsius_to_fahrenheit = (1.8 * degress_celsius) + 32
print(celsius_to_fahrenheit)

fahrenheit_to_celsius = (celsius_to_fahrenheit-32) / 1.8
print(fahrenheit_to_celsius)
