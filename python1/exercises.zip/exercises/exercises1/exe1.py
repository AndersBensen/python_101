
for i in range(20): 
    if (i < 10):
        print("Hej Anders")
    else: 
        print("Jeg elsker albani")
