from flask import Flask

class API:
    app = Flask(__name__)
    def __init__(self, db):
        self.db = db

    @app.route('/api/stock/<name>')
    def get_name(self, name):
        return self.db.get_specific_stock(name)

    @app.route('/api/stock/')
    def get_all(self):
        return self.db.get_all_stocks()
    
    def run(self, port):
        self.app.run(debug=True, port=port)