import sqlite3 

class DataBase:
    def __init__(self, con):
        self.con = con

    def get_all_stocks(self):
        cur = self.con.cursor()
        result = cur.execute("SELECT * FROM stocks")
        print("harro",result)
        return result.fetchall()

    def get_specific_stock(self, name):
        cur = self.con.cursor()
        query = f"SELECT * FROM stocks WHERE name = '{name}'"
        print(query)
        result = cur.execute(query)
        return result.fetchall()