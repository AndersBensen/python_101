from flask import Flask
import psycopg2
from database import DataBase
from api import API
import sqlite3

if __name__ == '__main__':

    # con = psycopg2.connect(
    #     host='localhost',
    #     port=54320,
    #     dbname='beer_db',
    #     user='postgres',
    #     password='my_password',
    # )
    con = sqlite3.connect('mydb.db')

    db = DataBase(con)
    api = API(db)
    api.run(8000)