one_hundred_numbers = list(range(100))

# Get every 7th number between 20 and 80
one_hundred_numbers_filtered = one_hundred_numbers[20:80:7]

print(one_hundred_numbers_filtered)